import os
print(os.getswd)
