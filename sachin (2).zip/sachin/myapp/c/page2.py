x=10
print(f"sachi")