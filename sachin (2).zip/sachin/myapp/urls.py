from myapp import views
from django.urls import URLPattern, path

urlpatterns = [
    path('timesheet/',views.nod,name="hi"),
    path('add/',views.add,name="jai"),
    path('delete/',views.delete1,name="jai1"),
    path('persantage/',views.per,name="s"),

]