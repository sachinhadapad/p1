from django.db import models
from email.policy import default
from unittest.util import _MAX_LENGTH

# Create your models here.

class  Student(models.Model):
    name=models.CharField(max_length = 50)
    roll_num=models.IntegerField(primary_key=True)
    school=models.CharField(max_length=50,default="ROYAL PALACE SCHOOL")

class Timesheets1(models.Model):
    day = models.CharField(max_length=50)
    date = models.DateField()
    rollnum = models.CharField(max_length=50)















    
class Loginadmin(models.Model):
    username = models.CharField(max_length = 50)
    password = models.CharField(max_length = 50,primary_key = True)



class AppraisalMngSystem(models.Model):
    emp_ID = models.CharField(max_length = 50,primary_key = True)
    jobknowledge = models.CharField(max_length = 50)
    workquality = models.CharField(max_length = 50)
    techskills  = models.CharField(max_length = 50)
    salary = models.IntegerField()
    appraise = models.IntegerField()

class Employee(models.Model):
    name = models.CharField(max_length=40)
    address = models.CharField(max_length=120,default="Zensar")
    empID = models.IntegerField(primary_key = True)
  




    




