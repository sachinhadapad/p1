from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from .models import Student, Timesheets1,AppraisalMngSystem,Employee
from django.contrib.auth.models import User
# Create your views here.


"""""
def createuser(request):
    if request.method == 'POST':
        usern = request.POST.get("username")
        passw = request.POST.get("password")
        a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
        a = a.save()
        
    else:
        return render(request,"adminlog.html",context={})   
    
    return HttpResponseRedirect('/empmng/')

def emp(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        address = request.POST.get("address")
        empID = request.POST.get("empID")
        b = Employee(name,address,empID)
        b.save()

    else:
        return render(request,"manage_emp.html",context={})   
    

def timesheet(request):
    if request.method == 'POST':
        d = request.POST.get("day")
        da = request.POST.get("date")
        t_in = request.POST.get("timein")
        t_out = request.POST.get("timeout")
        t_hours = request.POST.get("totalhours")
        dept_ID = request.POST.get("deptID")
        c = Timesheets1(day=d,date=da,timein=t_in,timeout=t_out,totalhours=t_hours,deptID=dept_ID)
        c.save()
    else:
        return render(request,"tsheet.html",context={})    
    return HttpResponse("Timesheet Updated!")

def appraisal(request):
    if request.method == 'POST':
        empid = request.POST.get("emp_ID")
        jobknow = request.POST.get("jobknowledge")
        workq = request.POST.get("workquality")
        techs = request.POST.get("techskills")
        sal = request.POST.get("salary")
        app = request.POST.get("appraise")
        d = AppraisalMngSystem(emp_ID=empid,jobknowledge=jobknow,workquality = workq,techskills=techs,salary=sal,appraise=app)
        d.save()
    else:
        return render(request,"appraisal.html",context={})       
    return HttpResponse("Appraisal Added!")
from django.shortcuts import render
from django.http import HttpResponse
from .models import Timesheets1,AppraisalMngSystem,Employee
from django.contrib.auth.models import User
# Create your views here.

def createuser(request):
    if request.method == 'POST':
        usern = request.POST.get("username")
        passw = request.POST.get("password")
        a = User.objects.create_user(username = usern,password = passw,is_staff = True, is_active = True, is_superuser = True)
        a = a.save()
    else:
        return render(request,"adminlog.html",context={})   
    return HttpResponseRedirect('/empmng/')    

def emp(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        address = request.POST.get("address")
        empID = request.POST.get("empID")
        b = Employee(name,address,empID)
        b.save()
    else:
        return render(request,"manage_emp.html",context={})   
    return HttpResponseRedirect('/nodnu/')



def appraisal(request):
    if request.method == 'POST':
        empid = request.POST.get("emp_ID")
        jobknow = request.POST.get("jobknowledge")
        workq = request.POST.get("workquality")
        techs = request.POST.get("techskills")
        sal = request.POST.get("salary")
        app = request.POST.get("appraise")
        d = AppraisalMngSystem(emp_ID=empid,jobknowledge=jobknow,workquality = workq,techskills=techs,salary=sal,appraise=app)
        d.save()
    else:
        return render(request,"appraisal.html",context={})       
    return HttpResponse("Appraisal Added!")
    """

def nod(request):
    return render(request,'tsheet.html')


def timesheet(request):
    if request.method == 'POST':
        d = request.POST.get("day")
        da = request.POST.get("date")
        dept_ID = request.POST.get("deptID")
        c = Timesheets1(day=d,date=da,roll_num=dept_ID)
        c.save()
    else:
        return render(request,"tsheet.html",context={})    
    return HttpResponse("Timesheet Updated!")

def add(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        rollnum = request.POST.get("rollnum")
        b = Student(name,roll_num=rollnum)
        b.save()
    else:
        return render(request,"page2.html",context={})   
    return HttpResponseRedirect('/nodnu/')


def delete1(request):
     if request.method == 'POST':
        member = Student.objects.get("rol_num")
        member.delete()
        
     else:
        return render(request,"del.html",context={})
     return HttpResponse("deleted")

def per(request):
     if request.method == 'POST':
        rollnum = request.POST.get("rollnum")

     else:

        return render(request,"per.html",context={})
     return HttpResponse("")



     
    
  




